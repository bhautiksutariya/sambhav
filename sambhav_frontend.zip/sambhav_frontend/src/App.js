import React, { Component } from "react";
import "./App.css";
import Header from "./Components/Header";
import Product from "./Components/Product";
import Categories from "./Components/Categories";
import ProductDetails from "./Components/ProductDetails";

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header />
        <Categories />
        <Product />
        <ProductDetails />
      </div>
    );
  }
}

export default App;
