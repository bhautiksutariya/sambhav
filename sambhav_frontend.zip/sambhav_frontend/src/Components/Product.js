import React, { Component } from "react";
class Product extends Component {
  render() {
    return (
      <div className="owl-stage">
        <div className="owl-item active" style={{ width: "280px" }}>
          <div className="product_items">
            <article className="single_product">
              <figure>
                <div className="product_thumb">
                  <a className="primary_img" href="product-details.html">
                    <img src="img/product/product13.jpg" alt="" />
                  </a>
                  <a className="secondary_img" href="product-details.html">
                    <img src="img/product/product14.jpg" alt="" />
                  </a>
                  <div className="label_product">
                    <span className="label_sale">Sale</span>
                  </div>
                  <div className="action_links">
                    <ul>
                      <li className="wishlist">
                        <a
                          href="wishlist.html"
                          title=""
                          data-original-title="Add to Wishlist"
                        >
                          <i className="ion-android-favorite-outline"></i>
                        </a>
                      </li>
                      <li className="compare">
                        <a
                          href="#"
                          title=""
                          data-original-title="Add to Compare"
                        >
                          <i className="ion-ios-settings-strong"></i>
                        </a>
                      </li>
                      <li className="quick_button">
                        <a
                          href="#"
                          data-toggle="modal"
                          data-target="#modal_box"
                          title=""
                          data-original-title="quick view"
                        >
                          <i className="ion-ios-search-strong"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="product_content">
                  <div className="product_content_inner">
                    <h4 className="product_name">
                      <a href="product-details.html">
                        Nostrum exercitationem itae neque nulla nec posuere sem
                      </a>
                    </h4>
                    <div className="price_box">
                      <span className="old_price">$70.00</span>
                      <span className="current_price">$68.00</span>
                    </div>
                  </div>
                  <div className="add_to_cart">
                    <a
                      href="cart.html"
                      title=""
                      data-original-title="Add to cart"
                    >
                      Add to cart
                    </a>
                  </div>
                </div>
              </figure>
            </article>
            <article className="single_product">
              <figure>
                <div className="product_thumb">
                  <a className="primary_img" href="product-details.html">
                    <img src="img/product/product15.jpg" alt="" />
                  </a>
                  <a className="secondary_img" href="product-details.html">
                    <img src="img/product/product16.jpg" alt="" />
                  </a>
                  <div className="label_product">
                    <span className="label_sale">Sale</span>
                  </div>
                  <div className="action_links">
                    <ul>
                      <li className="wishlist">
                        <a
                          href="wishlist.html"
                          title=""
                          data-original-title="Add to Wishlist"
                        >
                          <i className="ion-android-favorite-outline"></i>
                        </a>
                      </li>
                      <li className="compare">
                        <a
                          href="#"
                          title=""
                          data-original-title="Add to Compare"
                        >
                          <i className="ion-ios-settings-strong"></i>
                        </a>
                      </li>
                      <li className="quick_button">
                        <a
                          href="#"
                          data-toggle="modal"
                          data-target="#modal_box"
                          title=""
                          data-original-title="quick view"
                        >
                          <i className="ion-ios-search-strong"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="product_content">
                  <div className="product_content_inner">
                    <h4 className="product_name">
                      <a href="product-details.html">
                        Porro quisquam eget feugiat pretium posuere maximus
                      </a>
                    </h4>
                    <div className="price_box">
                      <span className="old_price">$65.00</span>
                      <span className="current_price">$60.00</span>
                    </div>
                  </div>
                  <div className="add_to_cart">
                    <a
                      href="cart.html"
                      title=""
                      data-original-title="Add to cart"
                    >
                      Add to cart
                    </a>
                  </div>
                </div>
              </figure>
            </article>
            <article className="single_product">
              <figure>
                <div className="product_thumb">
                  <a className="primary_img" href="product-details.html">
                    <img src="img/product/product15.jpg" alt="" />
                  </a>
                  <a className="secondary_img" href="product-details.html">
                    <img src="img/product/product16.jpg" alt="" />
                  </a>
                  <div className="label_product">
                    <span className="label_sale">Sale</span>
                  </div>
                  <div className="action_links">
                    <ul>
                      <li className="wishlist">
                        <a
                          href="wishlist.html"
                          title=""
                          data-original-title="Add to Wishlist"
                        >
                          <i className="ion-android-favorite-outline"></i>
                        </a>
                      </li>
                      <li className="compare">
                        <a
                          href="#"
                          title=""
                          data-original-title="Add to Compare"
                        >
                          <i className="ion-ios-settings-strong"></i>
                        </a>
                      </li>
                      <li className="quick_button">
                        <a
                          href="#"
                          data-toggle="modal"
                          data-target="#modal_box"
                          title=""
                          data-original-title="quick view"
                        >
                          <i className="ion-ios-search-strong"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="product_content">
                  <div className="product_content_inner">
                    <h4 className="product_name">
                      <a href="product-details.html">
                        Porro quisquam eget feugiat pretium posuere maximus
                      </a>
                    </h4>
                    <div className="price_box">
                      <span className="old_price">$65.00</span>
                      <span className="current_price">$60.00</span>
                    </div>
                  </div>
                  <div className="add_to_cart">
                    <a
                      href="cart.html"
                      title=""
                      data-original-title="Add to cart"
                    >
                      Add to cart
                    </a>
                  </div>
                </div>
              </figure>
            </article>
            <article className="single_product">
              <figure>
                <div className="product_thumb">
                  <a className="primary_img" href="product-details.html">
                    <img src="img/product/product15.jpg" alt="" />
                  </a>
                  <a className="secondary_img" href="product-details.html">
                    <img src="img/product/product16.jpg" alt="" />
                  </a>
                  <div className="label_product">
                    <span className="label_sale">Sale</span>
                  </div>
                  <div className="action_links">
                    <ul>
                      <li className="wishlist">
                        <a
                          href="wishlist.html"
                          title=""
                          data-original-title="Add to Wishlist"
                        >
                          <i className="ion-android-favorite-outline"></i>
                        </a>
                      </li>
                      <li className="compare">
                        <a
                          href="#"
                          title=""
                          data-original-title="Add to Compare"
                        >
                          <i className="ion-ios-settings-strong"></i>
                        </a>
                      </li>
                      <li className="quick_button">
                        <a
                          href="#"
                          data-toggle="modal"
                          data-target="#modal_box"
                          title=""
                          data-original-title="quick view"
                        >
                          <i className="ion-ios-search-strong"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="product_content">
                  <div className="product_content_inner">
                    <h4 className="product_name">
                      <a href="product-details.html">
                        Porro quisquam eget feugiat pretium posuere maximus
                      </a>
                    </h4>
                    <div className="price_box">
                      <span className="old_price">$65.00</span>
                      <span className="current_price">$60.00</span>
                    </div>
                  </div>
                  <div className="add_to_cart">
                    <a
                      href="cart.html"
                      title=""
                      data-original-title="Add to cart"
                    >
                      Add to cart
                    </a>
                  </div>
                </div>
              </figure>
            </article>
          </div>
        </div>
      </div>
      // <div className="col-4">
      //   <div className="tab-content">
      //     <div className="tab-pane fade show active" id="Fashion2" role="tabpanel">
      //       <div className="product_carousel small_p_container  small_product_column3 owl-carousel">
      //         <div className="product_items">
      //           <figure className="single_product">
      //             <div className="product_thumb">
      //               <a className="primary_img" href="product-details.html">
      //                 <img src="img/product/product1.jpg" alt="" />
      //               </a>
      //               <a className="secondary_img" href="product-details.html">
      //                 <img src="img/product/product2.jpg" alt="" />
      //               </a>
      //             </div>
      //             <div className="product_content">
      //               <h4 className="product_name">
      //                 <a href="product-details.html">
      //                   Officiis debitis varius risus dignissim massa quis
      //                 </a>
      //               </h4>
      //               <div className="product_rating">
      //                 <ul>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                 </ul>
      //               </div>
      //               <div className="price_box">
      //                 <span className="old_price">$86.00</span>
      //                 <span className="current_price">$79.00</span>
      //               </div>
      //               <div className="product_cart_button">
      //                 <a href="cart.html" title="Add to cart">
      //                   <i className="fa fa-shopping-bag"></i>
      //                 </a>
      //               </div>
      //             </div>
      //           </figure>
      //           <figure className="single_product">
      //             <div className="product_thumb">
      //               <a className="primary_img" href="product-details.html">
      //                 <img src="img/product/product1.jpg" alt="" />
      //               </a>
      //               <a className="secondary_img" href="product-details.html">
      //                 <img src="img/product/product2.jpg" alt="" />
      //               </a>
      //             </div>
      //             <div className="product_content">
      //               <h4 className="product_name">
      //                 <a href="product-details.html">
      //                   Officiis debitis varius risus dignissim massa quis
      //                 </a>
      //               </h4>
      //               <div className="product_rating">
      //                 <ul>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                 </ul>
      //               </div>
      //               <div className="price_box">
      //                 <span className="old_price">$86.00</span>
      //                 <span className="current_price">$79.00</span>
      //               </div>
      //               <div className="product_cart_button">
      //                 <a href="cart.html" title="Add to cart">
      //                   <i className="fa fa-shopping-bag"></i>
      //                 </a>
      //               </div>
      //             </div>
      //           </figure>
      //           <figure className="single_product">
      //             <div className="product_thumb">
      //               <a className="primary_img" href="product-details.html">
      //                 <img src="img/product/product1.jpg" alt="" />
      //               </a>
      //               <a className="secondary_img" href="product-details.html">
      //                 <img src="img/product/product2.jpg" alt="" />
      //               </a>
      //             </div>
      //             <div className="product_content">
      //               <h4 className="product_name">
      //                 <a href="product-details.html">
      //                   Officiis debitis varius risus dignissim massa quis
      //                 </a>
      //               </h4>
      //               <div className="product_rating">
      //                 <ul>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                 </ul>
      //               </div>
      //               <div className="price_box">
      //                 <span className="old_price">$86.00</span>
      //                 <span className="current_price">$79.00</span>
      //               </div>
      //               <div className="product_cart_button">
      //                 <a href="cart.html" title="Add to cart">
      //                   <i className="fa fa-shopping-bag"></i>
      //                 </a>
      //               </div>
      //             </div>
      //           </figure>
      //           <figure className="single_product">
      //             <div className="product_thumb">
      //               <a className="primary_img" href="product-details.html">
      //                 <img src="img/product/product1.jpg" alt="" />
      //               </a>
      //               <a className="secondary_img" href="product-details.html">
      //                 <img src="img/product/product2.jpg" alt="" />
      //               </a>
      //             </div>
      //             <div className="product_content">
      //               <h4 className="product_name">
      //                 <a href="product-details.html">
      //                   Officiis debitis varius risus dignissim massa quis
      //                 </a>
      //               </h4>
      //               <div className="product_rating">
      //                 <ul>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                   <li>
      //                     <a href="#">
      //                       <i className="ion-android-star-outline"></i>
      //                     </a>
      //                   </li>
      //                 </ul>
      //               </div>
      //               <div className="price_box">
      //                 <span className="old_price">$86.00</span>
      //                 <span className="current_price">$79.00</span>
      //               </div>
      //               <div className="product_cart_button">
      //                 <a href="cart.html" title="Add to cart">
      //                   <i className="fa fa-shopping-bag"></i>
      //                 </a>
      //               </div>
      //             </div>
      //           </figure>
      //         </div>
      //       </div>
      //     </div>
      //   </div>
      // </div>
    );
  }
}

export default Product;
