import React, { Component } from "react";

class Categories extends Component {
  constructor(props) {
    super(props);
    this.state = {
      categories: []
    };
  }
  componentDidMount() {
    // client({
    //   method: "GET",
    //   path: "https://sambhav1.herokuapp.com/rest/getCategory"
    // }).done(response => {
    //   this.setState({ categories: response.entity._embedded.getCategory });
    // });
    fetch("https://sambhav1.herokuapp.com/rest/getCategory", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization:
          "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxMiIsImlhdCI6MTU3MzY1MzUzOCwiZXhwIjoxNTc0MjU4MzM4fQ.RGS8O-Ggtf_e-xm8QhVSEzZYyOaPMjX0_ekAMWOZoGa0i_aFPRrTgBxdr31nwGLdyeqbrKC2Kec_uYOLcH34cw"
      }
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        let responsecategory = data.map(category => {
          return { value: category.categoryid, display: category.categoryname };
        });
        this.setState({
          categories: [{ value: "-1", display: "(Select category)" }].concat(
            responsecategory
          )
        });
        console.log(responsecategory);
      })
      .catch(error => {
        console.log(error);
      });
  }
  render() {
    return (
      <div className="column2 col-lg-6 ">
        <div className="search_container">
          <form action="#">
            <div className="hover_category">
              <select
                className="select_option"
                name="select"
                id="categori2"
                // style={{ display: "none" }}
              >
                <option>hi</option>
                {this.state.categories.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.display}
                  </option>
                ))}
              </select>

              {/* <div className="nice-select select_option open" tabindex="0">
                <span className="current">All Categories</span>
                <ul className="list">
                  <li data-value="1" className="option selected focus">
                    All Categories
                  </li>
                  <li data-value="2" className="option">
                    Accessories
                  </li>
                  <li data-value="3" className="option">
                    Accessories &amp; More
                  </li>
                  <li data-value="4" className="option">
                    Butters &amp; Eggs
                  </li>
                  <li data-value="5" className="option">
                    Camera &amp; Video{" "}
                  </li>
                  <li data-value="6" className="option">
                    Mornitors
                  </li>
                  <li data-value="7" className="option">
                    Tablets
                  </li>
                  <li data-value="8" className="option">
                    Laptops
                  </li>
                  <li data-value="9" className="option">
                    Handbags
                  </li>
                  <li data-value="10" className="option">
                    Headphone &amp; Speaker
                  </li>
                  <li data-value="11" className="option">
                    Herbs &amp; botanicals
                  </li>
                  <li data-value="12" className="option">
                    Vegetables
                  </li>
                  <li data-value="13" className="option">
                    Shop
                  </li>
                  <li data-value="14" className="option">
                    Laptops &amp; Desktops
                  </li>
                  <li data-value="15" className="option">
                    Watchs
                  </li>
                  <li data-value="16" className="option">
                    Electronic
                  </li>
                </ul>
              </div> */}
            </div>
            <div className="search_box">
              <input placeholder="Search product..." type="text" />
              <button type="submit">Search</button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Categories;
