import React, { Component } from "react";
class Category extends Component {
  render() {
    return <option value="">{this.props.item.categoryname}</option>;
  }
}

export default Category;
