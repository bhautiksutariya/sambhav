import React, { Component } from "react";
class Products extends Component {
  render() {
    return <div></div>;
  }
}

export default Products;
